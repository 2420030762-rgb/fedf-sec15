export const books = [
  { id: 1, title: "Let Us C", author: "Yashwant Kanetkar", price: 499, availability: "in stock" },
  { id: 2, title: "Learn React", author: "Jane Smith", price: 699, availability: "in stock" },
  { id: 3, title: "Node.js in Action", author: "Mark Lee", price: 599, availability: "out of stock" },
  { id: 4, title: "Mein Kampf", author: "Austrian Painter", price: 1945, availability: "in stock" }
];
